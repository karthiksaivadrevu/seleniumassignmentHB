package com.hotelbooking.testscripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import com.hotelbooking.pages.LoginPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTest
{
	private WebDriver driver;
	private LoginForm loginform;
	
	@Given("user to launch browser and go to the application")
	public void launch_browser_application() 
	{
		System.setProperty("webdriver.chrome.driver", "resources//chromedriver-V86.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();	
		driver.get("C:\\Users\\Karthik\\Desktop\\HotelBooking\\resources\\login.html");
	}

	@When("user in login form")
	public void login_page()
	{
		loginform = new LoginForm(driver);
		Assert.assertEquals(loginform.verifyHeading(), "Hotel Booking App");
		System.out.println("Login page validation is passed.");
				
	}

	@And("user clicks username and enters value {string}")
	public void user_clicks_username_and_enters_value(String uname)
	{
		System.out.println("RESULT: "+loginform.enterUsername(uname));
	}

	@And("user clicks password and enters value {string}")
	public void user_clicks_password_and_enters_value(String pswd)
	{
		System.out.println("RESULT: "+loginform.enterPassword(pswd));
	}
	
	@And("user clicks login button")
	public void user_clicks_login_button()
	{
		System.out.println("RESULT: "+loginform.clickLoginBtn());
	}

	@Then("user close the browser")
	public void user_close_the_browser()
	{
		driver.close();
	}
}