package Hotelbookingpage;

public class Loginpage {

}
